﻿using System;

namespace com.cognizant.movie.dao {
    public class FavoritesEmptyException : Exception {
        private string _message;

        public FavoritesEmptyException() {

        }

        public FavoritesEmptyException(string _message) {
            this._message = _message;
        }

        public string Message {
            get {
                return _message;
            }
            set {
                _message = value;
            }
        }

        public override string ToString() {
            return string.Format("{0}",this._message);
        }
    }
}
