﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.model {
    public class Favorites {

        private List<Movie> _movieList = new List<Movie>();
        private double _total;

        public Favorites() {

        }

        public Favorites(List<Movie> _movieList, double _total) {
            this._movieList = _movieList;
            this._total = _total;
        }

        public List<Movie> MovieList {
            get {
                return _movieList;
            }
            set {
                _movieList = value;
            }
        }

        public double Total {
            get {
                return _total;
            }
            set {
                _total = value;
            }
        }

        public override string ToString() {
            string movieInfo = string.Empty;
            foreach(Movie movie in MovieList) {
                movieInfo = movieInfo + movie.Title + "       " + movie.Active 
                + "       " + (double)movie.Budget;
            }
            return string.Format("{0}\n{1}", movieInfo, this.Total);
        }
    }
}
