﻿using System;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
namespace MovieCruiserConsole {
    class FavoritesDaoCollectionImplTest {
        public FavoritesDaoCollectionImplTest() {
            testAddFavorite();
            testRemoveFavorite();
        }
        public static void testAddFavorite() {
            FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
            favoriteDao.addFavorite(1,1001);
            favoriteDao.addFavorite(1,1002);
            favoriteDao.addFavorite(1,1003);
            try {
                Console.WriteLine("\nFavorite List after adding Data:-");
                testGetAllFavorites();
            } catch (FavoritesEmptyException favoriteEmpty){
                Console.WriteLine(favoriteEmpty);
            }
        }

        public static void testGetAllFavorites() {
            FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
            Favorites favorite = favoriteDao.getAllFavorites(1);
            Console.WriteLine("\nName               Active                Budget");
            for (int i = 0; i < favorite.MovieList.Count; i++) {
                Console.WriteLine("{0,-20}{1,-20}{2}", favorite.MovieList[i].Title,
                favorite.MovieList[i].Active == true ? "Yes" : "No",(double)favorite.MovieList[i].Budget);
            }
            Console.WriteLine("Total : " + favorite.Total);
        }

        public static void testRemoveFavorite() {
            FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
            Console.WriteLine("\nFavorite List before removing Data");
            try {
                testGetAllFavorites();
            } catch (FavoritesEmptyException favoriteEmpty) {
                Console.WriteLine(favoriteEmpty);
            }
            favoriteDao.removeFavorite(1,1001);
            Console.WriteLine("\nFavorite List After removing Data");
            try {
                testGetAllFavorites();
            } catch (FavoritesEmptyException favoriteEmpty) {
                Console.WriteLine(favoriteEmpty);
            }
        }
    }
}
