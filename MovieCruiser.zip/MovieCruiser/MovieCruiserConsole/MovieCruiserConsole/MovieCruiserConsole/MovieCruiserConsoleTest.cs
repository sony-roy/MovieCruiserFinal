﻿using System;

namespace MovieCruiserConsole {
    class MovieCruiserConsoleTest {
        public static void Main(string[] args) {
            int movie = 0;
            do {
                Console.WriteLine("1 . Movie Information \n2 . Favorite Information \n3 . Exit");
                movie = int.Parse(Console.ReadLine());
                switch (movie) {
                    case 1:
                        MovieDaoCollectionImplTest movieDao = new MovieDaoCollectionImplTest();
                        Console.WriteLine();
                        break;
                    case 2:
                        FavoritesDaoCollectionImplTest favoriteDao = 
                        new FavoritesDaoCollectionImplTest();
                        Console.WriteLine();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
                Console.WriteLine("Do you want to continue ? ");
            } while (movie != 3);
        }
    }
}
