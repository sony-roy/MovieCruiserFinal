﻿using System;
using System.Collections.Generic;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using com.cognizant.movie.util;
namespace MovieCruiserConsole{
    class MovieDaoCollectionImplTest {
        public MovieDaoCollectionImplTest() {
            testGetMovieListAdmin();
            testGetMovieListCustomer();
            testModifyMovie();
            testGetMovie();
        }

        public static void testGetMovieListAdmin() {
            Console.WriteLine("\nAdmin List :-\n");
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListAdmin();
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
             "Active", "Date Of Launch", "Genre", "Has Teaser");
            foreach (Movie movie in movieList) {
               Console.WriteLine(movie);
            }
        }

        public static void testGetMovieListCustomer() {
            Console.WriteLine("\nCustomer List :-\n");
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListCustomer();
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
             "Active", "Date Of Launch", "Genre", "Has Teaser");
            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testModifyMovie() {
            Movie movie = new Movie(1003, "Avatar", 175000000f, true,
                DateUtil.convertToDate("08/03/2019"), "Action", false);
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();

            Console.WriteLine("\nBefore Modification :-\n");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
             "Active", "Date Of Launch", "Genre", "Has Teaser");
            Console.WriteLine(movieDao.getMovie(movie.Id));

            movieDao.modifyMovie(movie);
            Console.WriteLine("\nAfter Modification :-\n");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
             "Active", "Date Of Launch", "Genre", "Has Teaser");
            Console.WriteLine(movieDao.getMovie(movie.Id));
        }

        public static void testGetMovie() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(1002);
            Console.WriteLine("\nMovie Details fetched by ID :-\n");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
             "Active", "Date Of Launch", "Genre", "Has Teaser");
            Console.WriteLine(movie);
        }
    }
}
