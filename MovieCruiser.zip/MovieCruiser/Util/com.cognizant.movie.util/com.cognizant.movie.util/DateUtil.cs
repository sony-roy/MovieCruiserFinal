﻿using System;
namespace com.cognizant.movie.util {
    public class DateUtil {
        public static DateTime convertToDate(string date) {
            return DateTime.ParseExact(date, "dd/MM/yyyy", null);
        }
    }
}
